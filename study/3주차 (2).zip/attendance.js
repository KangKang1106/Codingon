let checkTd = document.querySelector('td');
checkTd.addEventListener('click', function () {
    checkTd.style.backgroundColor = 'gray';
    checkTd.style.fontWeight = 'bold';
})
let checkName = document.querySelectorAll('.checkName');